package com.senai.biblioteca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BibliotecaSenaiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BibliotecaSenaiApplication.class, args);
	}

}
